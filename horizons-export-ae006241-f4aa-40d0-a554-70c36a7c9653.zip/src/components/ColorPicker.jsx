
import React from 'react';
import { motion } from 'framer-motion';
import { Palette } from 'lucide-react';
import { Label } from '@/components/ui/label';

const colorPresets = [
  { name: 'Ocean Blue', primary: '#667eea', secondary: '#764ba2', accent: '#f093fb' },
  { name: 'Sunset', primary: '#ff7e5f', secondary: '#feb47b', accent: '#ff6b6b' },
  { name: 'Forest', primary: '#11998e', secondary: '#38ef7d', accent: '#4facfe' },
  { name: 'Purple Rain', primary: '#667eea', secondary: '#764ba2', accent: '#f093fb' },
  { name: 'Coral', primary: '#ff9a9e', secondary: '#fecfef', accent: '#ffecd2' },
  { name: 'Midnight', primary: '#2c3e50', secondary: '#3498db', accent: '#9b59b6' }
];

const ColorPicker = ({ selectedColors, onColorsChange }) => {
  const handlePresetSelect = (preset) => {
    onColorsChange({
      primary: preset.primary,
      secondary: preset.secondary,
      accent: preset.accent
    });
  };

  const handleColorChange = (colorType, value) => {
    onColorsChange({
      ...selectedColors,
      [colorType]: value
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="space-y-6"
    >
      <div className="flex items-center space-x-2">
        <Palette className="w-5 h-5 text-blue-600" />
        <h3 className="text-lg font-semibold">Color Scheme</h3>
      </div>

      <div className="space-y-4">
        <div>
          <Label className="text-sm font-medium mb-3 block">Color Presets</Label>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {colorPresets.map((preset, index) => (
              <motion.button
                key={index}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => handlePresetSelect(preset)}
                className="p-3 rounded-lg border border-gray-200 hover:border-gray-300 transition-colors"
              >
                <div className="flex space-x-1 mb-2">
                  <div
                    className="w-4 h-4 rounded-full"
                    style={{ backgroundColor: preset.primary }}
                  />
                  <div
                    className="w-4 h-4 rounded-full"
                    style={{ backgroundColor: preset.secondary }}
                  />
                  <div
                    className="w-4 h-4 rounded-full"
                    style={{ backgroundColor: preset.accent }}
                  />
                </div>
                <p className="text-xs font-medium">{preset.name}</p>
              </motion.button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="space-y-2">
            <Label htmlFor="primary">Primary Color</Label>
            <div className="flex items-center space-x-2">
              <input
                id="primary"
                type="color"
                value={selectedColors.primary}
                onChange={(e) => handleColorChange('primary', e.target.value)}
                className="w-12 h-10 rounded border border-gray-300 cursor-pointer"
              />
              <input
                type="text"
                value={selectedColors.primary}
                onChange={(e) => handleColorChange('primary', e.target.value)}
                className="flex-1 px-3 py-2 border border-gray-300 rounded text-sm"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="secondary">Secondary Color</Label>
            <div className="flex items-center space-x-2">
              <input
                id="secondary"
                type="color"
                value={selectedColors.secondary}
                onChange={(e) => handleColorChange('secondary', e.target.value)}
                className="w-12 h-10 rounded border border-gray-300 cursor-pointer"
              />
              <input
                type="text"
                value={selectedColors.secondary}
                onChange={(e) => handleColorChange('secondary', e.target.value)}
                className="flex-1 px-3 py-2 border border-gray-300 rounded text-sm"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="accent">Accent Color</Label>
            <div className="flex items-center space-x-2">
              <input
                id="accent"
                type="color"
                value={selectedColors.accent}
                onChange={(e) => handleColorChange('accent', e.target.value)}
                className="w-12 h-10 rounded border border-gray-300 cursor-pointer"
              />
              <input
                type="text"
                value={selectedColors.accent}
                onChange={(e) => handleColorChange('accent', e.target.value)}
                className="flex-1 px-3 py-2 border border-gray-300 rounded text-sm"
              />
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default ColorPicker;
