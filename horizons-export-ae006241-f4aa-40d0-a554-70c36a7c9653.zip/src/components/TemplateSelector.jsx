
import React from 'react';
import { motion } from 'framer-motion';
import { Check } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

const templates = [
  {
    id: 'modern',
    name: 'Modern',
    description: 'Clean and contemporary design with bold typography',
    preview: 'bg-gradient-to-br from-blue-500 to-purple-600'
  },
  {
    id: 'classic',
    name: 'Classic',
    description: 'Traditional professional layout with elegant styling',
    preview: 'bg-gradient-to-br from-gray-600 to-gray-800'
  },
  {
    id: 'creative',
    name: 'Creative',
    description: 'Unique design with creative elements and vibrant colors',
    preview: 'bg-gradient-to-br from-pink-500 to-orange-500'
  }
];

const TemplateSelector = ({ selectedTemplate, onTemplateChange }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="space-y-4"
    >
      <h3 className="text-lg font-semibold">Choose Template</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {templates.map((template) => (
          <motion.div
            key={template.id}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Card
              className={`cursor-pointer transition-all duration-200 ${
                selectedTemplate === template.id
                  ? 'ring-2 ring-blue-500 shadow-lg'
                  : 'hover:shadow-md'
              }`}
              onClick={() => onTemplateChange(template.id)}
            >
              <CardContent className="p-4">
                <div className="relative">
                  <div className={`w-full h-24 rounded-lg ${template.preview} mb-3`}>
                    {selectedTemplate === template.id && (
                      <div className="absolute top-2 right-2 w-6 h-6 bg-white rounded-full flex items-center justify-center">
                        <Check className="w-4 h-4 text-blue-500" />
                      </div>
                    )}
                  </div>
                  <h4 className="font-semibold text-sm">{template.name}</h4>
                  <p className="text-xs text-gray-600 mt-1">{template.description}</p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default TemplateSelector;
