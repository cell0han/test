
import React from 'react';
import { motion } from 'framer-motion';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import PersonalInfoEditor from '@/components/editors/PersonalInfoEditor';
import ExperienceEditor from '@/components/editors/ExperienceEditor';
import EducationEditor from '@/components/editors/EducationEditor';
import SkillsEditor from '@/components/editors/SkillsEditor';
import ProjectsEditor from '@/components/editors/ProjectsEditor';
import TemplateSelector from '@/components/TemplateSelector';
import ColorPicker from '@/components/ColorPicker';

const ResumeEditor = ({
  resumeData,
  updateResumeData,
  selectedTemplate,
  setSelectedTemplate,
  selectedColors,
  setSelectedColors
}) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="bg-white/90 backdrop-blur-md rounded-2xl p-6 shadow-xl border border-white/20"
    >
      <div className="mb-6">
        <h2 className="text-2xl font-bold gradient-text font-display mb-2">Resume Editor</h2>
        <p className="text-gray-600">Fill in your information to create your professional resume</p>
      </div>

      <Tabs defaultValue="personal" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3 lg:grid-cols-6 gap-1">
          <TabsTrigger value="personal" className="text-xs">Personal</TabsTrigger>
          <TabsTrigger value="experience" className="text-xs">Experience</TabsTrigger>
          <TabsTrigger value="education" className="text-xs">Education</TabsTrigger>
          <TabsTrigger value="skills" className="text-xs">Skills</TabsTrigger>
          <TabsTrigger value="projects" className="text-xs">Projects</TabsTrigger>
          <TabsTrigger value="design" className="text-xs">Design</TabsTrigger>
        </TabsList>

        <TabsContent value="personal" className="space-y-4">
          <PersonalInfoEditor
            data={resumeData.personalInfo}
            onChange={(data) => updateResumeData('personalInfo', data)}
          />
        </TabsContent>

        <TabsContent value="experience" className="space-y-4">
          <ExperienceEditor
            data={resumeData.experience}
            onChange={(data) => updateResumeData('experience', data)}
          />
        </TabsContent>

        <TabsContent value="education" className="space-y-4">
          <EducationEditor
            data={resumeData.education}
            onChange={(data) => updateResumeData('education', data)}
          />
        </TabsContent>

        <TabsContent value="skills" className="space-y-4">
          <SkillsEditor
            data={resumeData.skills}
            onChange={(data) => updateResumeData('skills', data)}
          />
        </TabsContent>

        <TabsContent value="projects" className="space-y-4">
          <ProjectsEditor
            data={resumeData.projects}
            onChange={(data) => updateResumeData('projects', data)}
          />
        </TabsContent>

        <TabsContent value="design" className="space-y-6">
          <TemplateSelector
            selectedTemplate={selectedTemplate}
            onTemplateChange={setSelectedTemplate}
          />
          <ColorPicker
            selectedColors={selectedColors}
            onColorsChange={setSelectedColors}
          />
        </TabsContent>
      </Tabs>
    </motion.div>
  );
};

export default ResumeEditor;
