
import React from 'react';
import { motion } from 'framer-motion';
import ModernTemplate from '@/components/templates/ModernTemplate';
import ClassicTemplate from '@/components/templates/ClassicTemplate';
import CreativeTemplate from '@/components/templates/CreativeTemplate';

const ResumePreview = ({ resumeData, template, colors, fullScreen = false }) => {
  const getTemplate = () => {
    switch (template) {
      case 'classic':
        return <ClassicTemplate data={resumeData} colors={colors} />;
      case 'creative':
        return <CreativeTemplate data={resumeData} colors={colors} />;
      default:
        return <ModernTemplate data={resumeData} colors={colors} />;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
      className={`${fullScreen ? 'w-full' : ''}`}
    >
      <div className={`${fullScreen ? 'mb-6' : 'mb-4'}`}>
        <h3 className="text-lg font-semibold gradient-text font-display">Live Preview</h3>
        <p className="text-sm text-gray-600">See how your resume looks in real-time</p>
      </div>
      
      <div 
        id="resume-preview"
        className={`bg-white rounded-lg shadow-2xl overflow-hidden ${
          fullScreen ? 'max-w-4xl mx-auto' : 'max-w-2xl'
        } resume-shadow`}
        style={{ aspectRatio: '8.5/11' }}
      >
        {getTemplate()}
      </div>
    </motion.div>
  );
};

export default ResumePreview;
