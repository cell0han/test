
import React from 'react';
import { Mail, Phone, MapPin, Globe, Linkedin, Calendar } from 'lucide-react';

const ModernTemplate = ({ data, colors }) => {
  const { personalInfo, experience, education, skills, projects } = data;

  return (
    <div className="w-full h-full bg-white text-gray-800 overflow-hidden">
      {/* Header Section */}
      <div 
        className="px-8 py-6 text-white relative overflow-hidden"
        style={{ 
          background: `linear-gradient(135deg, ${colors.primary} 0%, ${colors.secondary} 100%)` 
        }}
      >
        <div className="relative z-10">
          <div className="flex items-start space-x-6">
            {personalInfo.profileImage && (
              <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-white/20 flex-shrink-0">
                <img 
                  src={personalInfo.profileImage} 
                  alt="Profile" 
                  className="w-full h-full object-cover"
                />
              </div>
            )}
            <div className="flex-1">
              <h1 className="text-3xl font-bold mb-2">{personalInfo.fullName || 'Your Name'}</h1>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm opacity-90">
                {personalInfo.email && (
                  <div className="flex items-center space-x-2">
                    <Mail className="w-4 h-4" />
                    <span>{personalInfo.email}</span>
                  </div>
                )}
                {personalInfo.phone && (
                  <div className="flex items-center space-x-2">
                    <Phone className="w-4 h-4" />
                    <span>{personalInfo.phone}</span>
                  </div>
                )}
                {personalInfo.location && (
                  <div className="flex items-center space-x-2">
                    <MapPin className="w-4 h-4" />
                    <span>{personalInfo.location}</span>
                  </div>
                )}
                {personalInfo.website && (
                  <div className="flex items-center space-x-2">
                    <Globe className="w-4 h-4" />
                    <span>{personalInfo.website}</span>
                  </div>
                )}
                {personalInfo.linkedin && (
                  <div className="flex items-center space-x-2 md:col-span-2">
                    <Linkedin className="w-4 h-4" />
                    <span>{personalInfo.linkedin}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
        <div 
          className="absolute top-0 right-0 w-32 h-32 rounded-full opacity-10"
          style={{ backgroundColor: colors.accent }}
        />
      </div>

      <div className="px-8 py-6 space-y-6">
        {/* Summary */}
        {personalInfo.summary && (
          <section>
            <h2 
              className="text-xl font-bold mb-3 pb-2 border-b-2"
              style={{ borderColor: colors.primary }}
            >
              Professional Summary
            </h2>
            <p className="text-gray-700 leading-relaxed">{personalInfo.summary}</p>
          </section>
        )}

        {/* Experience */}
        {experience.length > 0 && (
          <section>
            <h2 
              className="text-xl font-bold mb-4 pb-2 border-b-2"
              style={{ borderColor: colors.primary }}
            >
              Work Experience
            </h2>
            <div className="space-y-4">
              {experience.map((exp, index) => (
                <div key={index} className="relative">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h3 className="font-semibold text-lg">{exp.position}</h3>
                      <p className="font-medium" style={{ color: colors.primary }}>{exp.company}</p>
                    </div>
                    <div className="text-sm text-gray-600 flex items-center">
                      <Calendar className="w-4 h-4 mr-1" />
                      {exp.startDate} - {exp.endDate || 'Present'}
                    </div>
                  </div>
                  {exp.description && (
                    <p className="text-gray-700 text-sm leading-relaxed">{exp.description}</p>
                  )}
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Education */}
        {education.length > 0 && (
          <section>
            <h2 
              className="text-xl font-bold mb-4 pb-2 border-b-2"
              style={{ borderColor: colors.primary }}
            >
              Education
            </h2>
            <div className="space-y-3">
              {education.map((edu, index) => (
                <div key={index}>
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-semibold">{edu.degree} in {edu.field}</h3>
                      <p style={{ color: colors.primary }}>{edu.institution}</p>
                      {edu.gpa && <p className="text-sm text-gray-600">GPA: {edu.gpa}</p>}
                    </div>
                    <div className="text-sm text-gray-600">
                      {edu.startDate} - {edu.endDate}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Skills */}
        {skills.length > 0 && (
          <section>
            <h2 
              className="text-xl font-bold mb-4 pb-2 border-b-2"
              style={{ borderColor: colors.primary }}
            >
              Skills
            </h2>
            <div className="flex flex-wrap gap-2">
              {skills.map((skill, index) => (
                <span
                  key={index}
                  className="px-3 py-1 rounded-full text-sm font-medium text-white"
                  style={{ backgroundColor: colors.primary }}
                >
                  {skill}
                </span>
              ))}
            </div>
          </section>
        )}

        {/* Projects */}
        {projects.length > 0 && (
          <section>
            <h2 
              className="text-xl font-bold mb-4 pb-2 border-b-2"
              style={{ borderColor: colors.primary }}
            >
              Projects
            </h2>
            <div className="space-y-4">
              {projects.map((project, index) => (
                <div key={index}>
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-semibold text-lg">{project.name}</h3>
                    {project.technologies && (
                      <span className="text-sm text-gray-600">{project.technologies}</span>
                    )}
                  </div>
                  {project.description && (
                    <p className="text-gray-700 text-sm leading-relaxed mb-2">{project.description}</p>
                  )}
                  <div className="flex space-x-4 text-sm">
                    {project.url && (
                      <span style={{ color: colors.primary }}>🔗 {project.url}</span>
                    )}
                    {project.github && (
                      <span style={{ color: colors.primary }}>📁 {project.github}</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
};

export default ModernTemplate;
