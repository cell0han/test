
import React from 'react';
import { Mail, Phone, MapPin, Globe, Linkedin, Star } from 'lucide-react';

const CreativeTemplate = ({ data, colors }) => {
  const { personalInfo, experience, education, skills, projects } = data;

  return (
    <div className="w-full h-full bg-white text-gray-800 overflow-hidden relative">
      {/* Decorative Background Elements */}
      <div 
        className="absolute top-0 right-0 w-64 h-64 rounded-full opacity-5"
        style={{ backgroundColor: colors.accent, transform: 'translate(50%, -50%)' }}
      />
      <div 
        className="absolute bottom-0 left-0 w-48 h-48 rounded-full opacity-5"
        style={{ backgroundColor: colors.secondary, transform: 'translate(-50%, 50%)' }}
      />

      <div className="relative z-10">
        {/* Header Section */}
        <div className="flex">
          {/* Left Sidebar */}
          <div 
            className="w-1/3 p-6 text-white min-h-full"
            style={{ 
              background: `linear-gradient(180deg, ${colors.primary} 0%, ${colors.secondary} 100%)` 
            }}
          >
            {/* Profile Image */}
            {personalInfo.profileImage && (
              <div className="w-32 h-32 rounded-full overflow-hidden mx-auto mb-6 border-4 border-white/30">
                <img 
                  src={personalInfo.profileImage} 
                  alt="Profile" 
                  className="w-full h-full object-cover"
                />
              </div>
            )}

            {/* Contact Info */}
            <div className="space-y-4 mb-8">
              <h3 className="font-bold text-lg mb-4">Contact</h3>
              {personalInfo.email && (
                <div className="flex items-start space-x-3">
                  <Mail className="w-4 h-4 mt-0.5 flex-shrink-0" />
                  <span className="text-sm break-all">{personalInfo.email}</span>
                </div>
              )}
              {personalInfo.phone && (
                <div className="flex items-center space-x-3">
                  <Phone className="w-4 h-4 flex-shrink-0" />
                  <span className="text-sm">{personalInfo.phone}</span>
                </div>
              )}
              {personalInfo.location && (
                <div className="flex items-start space-x-3">
                  <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">{personalInfo.location}</span>
                </div>
              )}
              {personalInfo.website && (
                <div className="flex items-start space-x-3">
                  <Globe className="w-4 h-4 mt-0.5 flex-shrink-0" />
                  <span className="text-sm break-all">{personalInfo.website}</span>
                </div>
              )}
              {personalInfo.linkedin && (
                <div className="flex items-start space-x-3">
                  <Linkedin className="w-4 h-4 mt-0.5 flex-shrink-0" />
                  <span className="text-sm break-all">{personalInfo.linkedin}</span>
                </div>
              )}
            </div>

            {/* Skills */}
            {skills.length > 0 && (
              <div>
                <h3 className="font-bold text-lg mb-4">Skills</h3>
                <div className="space-y-2">
                  {skills.map((skill, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <Star className="w-3 h-3" style={{ color: colors.accent }} />
                      <span className="text-sm">{skill}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Main Content */}
          <div className="w-2/3 p-8">
            {/* Name and Title */}
            <div className="mb-8">
              <h1 className="text-4xl font-bold mb-2" style={{ color: colors.primary }}>
                {personalInfo.fullName || 'Your Name'}
              </h1>
              <div 
                className="w-16 h-1 mb-4"
                style={{ backgroundColor: colors.accent }}
              />
            </div>

            {/* Summary */}
            {personalInfo.summary && (
              <section className="mb-8">
                <h2 
                  className="text-xl font-bold mb-4 flex items-center"
                  style={{ color: colors.primary }}
                >
                  <div 
                    className="w-2 h-6 mr-3"
                    style={{ backgroundColor: colors.accent }}
                  />
                  About Me
                </h2>
                <p className="text-gray-700 leading-relaxed">{personalInfo.summary}</p>
              </section>
            )}

            {/* Experience */}
            {experience.length > 0 && (
              <section className="mb-8">
                <h2 
                  className="text-xl font-bold mb-6 flex items-center"
                  style={{ color: colors.primary }}
                >
                  <div 
                    className="w-2 h-6 mr-3"
                    style={{ backgroundColor: colors.accent }}
                  />
                  Experience
                </h2>
                <div className="space-y-6">
                  {experience.map((exp, index) => (
                    <div key={index} className="relative pl-6">
                      <div 
                        className="absolute left-0 top-2 w-3 h-3 rounded-full"
                        style={{ backgroundColor: colors.accent }}
                      />
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h3 className="font-bold text-lg">{exp.position}</h3>
                          <p className="font-semibold" style={{ color: colors.secondary }}>{exp.company}</p>
                        </div>
                        <div 
                          className="text-sm px-3 py-1 rounded-full text-white"
                          style={{ backgroundColor: colors.primary }}
                        >
                          {exp.startDate} - {exp.endDate || 'Present'}
                        </div>
                      </div>
                      {exp.description && (
                        <p className="text-gray-700 text-sm leading-relaxed">{exp.description}</p>
                      )}
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Education */}
            {education.length > 0 && (
              <section className="mb-8">
                <h2 
                  className="text-xl font-bold mb-6 flex items-center"
                  style={{ color: colors.primary }}
                >
                  <div 
                    className="w-2 h-6 mr-3"
                    style={{ backgroundColor: colors.accent }}
                  />
                  Education
                </h2>
                <div className="space-y-4">
                  {education.map((edu, index) => (
                    <div key={index} className="relative pl-6">
                      <div 
                        className="absolute left-0 top-2 w-3 h-3 rounded-full"
                        style={{ backgroundColor: colors.accent }}
                      />
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-bold">{edu.degree} in {edu.field}</h3>
                          <p style={{ color: colors.secondary }}>{edu.institution}</p>
                          {edu.gpa && <p className="text-sm text-gray-600">GPA: {edu.gpa}</p>}
                        </div>
                        <div className="text-sm text-gray-600">
                          {edu.startDate} - {edu.endDate}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Projects */}
            {projects.length > 0 && (
              <section>
                <h2 
                  className="text-xl font-bold mb-6 flex items-center"
                  style={{ color: colors.primary }}
                >
                  <div 
                    className="w-2 h-6 mr-3"
                    style={{ backgroundColor: colors.accent }}
                  />
                  Projects
                </h2>
                <div className="space-y-4">
                  {projects.map((project, index) => (
                    <div key={index} className="relative pl-6">
                      <div 
                        className="absolute left-0 top-2 w-3 h-3 rounded-full"
                        style={{ backgroundColor: colors.accent }}
                      />
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="font-bold text-lg">{project.name}</h3>
                        {project.technologies && (
                          <span 
                            className="text-xs px-2 py-1 rounded text-white"
                            style={{ backgroundColor: colors.secondary }}
                          >
                            {project.technologies}
                          </span>
                        )}
                      </div>
                      {project.description && (
                        <p className="text-gray-700 text-sm leading-relaxed mb-2">{project.description}</p>
                      )}
                      <div className="flex space-x-4 text-sm">
                        {project.url && (
                          <span style={{ color: colors.primary }}>🔗 {project.url}</span>
                        )}
                        {project.github && (
                          <span style={{ color: colors.primary }}>📁 {project.github}</span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreativeTemplate;
