
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Toaster } from '@/components/ui/toaster';
import Header from '@/components/Header';
import ResumeEditor from '@/components/ResumeEditor';
import ResumePreview from '@/components/ResumePreview';
import { useResumeData } from '@/hooks/useResumeData';

function App() {
  const [selectedTemplate, setSelectedTemplate] = useState('modern');
  const [selectedColors, setSelectedColors] = useState({
    primary: '#667eea',
    secondary: '#764ba2',
    accent: '#f093fb'
  });
  const [isPreviewMode, setIsPreviewMode] = useState(false);
  
  const { resumeData, updateResumeData } = useResumeData();

  return (
    <>
      <Helmet>
        <title>Resume Builder - Create Professional Resumes</title>
        <meta name="description" content="Build stunning professional resumes with our modern resume builder. Choose from multiple templates, customize colors, and export to PDF." />
      </Helmet>
      
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
        <Header 
          isPreviewMode={isPreviewMode}
          setIsPreviewMode={setIsPreviewMode}
          resumeData={resumeData}
        />
        
        <main className="container mx-auto px-4 py-8">
          {!isPreviewMode ? (
            <div className="grid lg:grid-cols-2 gap-8">
              <motion.div
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5 }}
              >
                <ResumeEditor
                  resumeData={resumeData}
                  updateResumeData={updateResumeData}
                  selectedTemplate={selectedTemplate}
                  setSelectedTemplate={setSelectedTemplate}
                  selectedColors={selectedColors}
                  setSelectedColors={setSelectedColors}
                />
              </motion.div>
              
              <motion.div
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="sticky top-8"
              >
                <ResumePreview
                  resumeData={resumeData}
                  template={selectedTemplate}
                  colors={selectedColors}
                />
              </motion.div>
            </div>
          ) : (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3 }}
              className="max-w-4xl mx-auto"
            >
              <ResumePreview
                resumeData={resumeData}
                template={selectedTemplate}
                colors={selectedColors}
                fullScreen={true}
              />
            </motion.div>
          )}
        </main>
        
        <Toaster />
      </div>
    </>
  );
}

export default App;
